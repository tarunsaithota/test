import React from 'react'

const PrivacyPolicy = () => {
  return (
    <div>
        <div className='w-full h-[20%] text-center my-20'>
            <h1 className='font-extrabold text-4xl text-customGreen'>Privacy Policy</h1>
        </div>
        <div>
            <p></p>
        </div>
    </div>
  )
}

export default PrivacyPolicy;