import './App.css';
import LandingPage from './Components/LandingPage';

const App = () => {
  return (
    <>
      <LandingPage />
    </>
  )
}

export default App;
